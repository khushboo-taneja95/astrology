class AstroDimens {
  static const int timeOutDuration = 80; 
  static const double smallLogoHeight = 36;
  static const double smallLogoWidth = 36;
  static const double backArrowHeight = 15;
  static const double backArrowWidth = 26;
}
