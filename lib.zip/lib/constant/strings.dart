class AstroString {
  static const String privacyPolicyURL = "https://vama.app/privacy-policy";

  static const String termsConditionsURL = "https://vama.app/terms-conditions";

  static const String noInternet = "Please check your Internet Connection!";
  static const String errorMessageOnAPICalledFailed =
      "Something went wrong, try again";

  static const String instagramURL = "https://www.instagram.com/vama_app/";
  static const String youtubeURL =
      "https://www.youtube.com/channel/UC8umwYtZ5jSBHBpRm7zgQIw";
  static const String linkedURL =
      "https://www.linkedin.com/company/selectastro";

  static const String facebookURL = "https://www.facebook.com/vamaapp";
  static const String supportNo = "1236547890";
}
